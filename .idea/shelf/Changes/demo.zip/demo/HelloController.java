package com.example.demo;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class HelloController {

    @FXML
    private TextField nameField;

    @FXML
    private Button login;

    private String savedName;

    @FXML
    private void handleLogin(ActionEvent event) {
        String name = nameField.getText().trim();

        if (name.isEmpty()) {
            // Show an alert if the name field is empty
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Login Error");
            alert.setHeaderText("Name Field is Empty");
            alert.setContentText("Please enter your name before logging in.");
            alert.showAndWait();
        } else {
            try {
                // Load the dashboard FXML file
                FXMLLoader loader = new FXMLLoader(getClass().getResource("Dashboard.fxml"));
                Scene dashboardScene = new Scene(loader.load());

                // Get the controller for the dashboard
                Dashboard controller = loader.getController();
                controller.setUsername(name); // Pass the username to the dashboard

                // Switch to the dashboard scene
                Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                stage.setScene(dashboardScene);
                stage.show();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }


    // Getter for the saved name (optional, if you need it elsewhere)
    public String getSavedName() {
        return savedName;
    }
}

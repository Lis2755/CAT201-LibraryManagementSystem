package com.example.demo;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.io.*;
import java.util.ArrayList;

public class Dashboard {

    @FXML
    private TableView<Book> bookTableView;  // TableView to display books

    private String username; // Add this line

    @FXML
    private TableColumn<Book, String> bookTitleColumn;
    @FXML
    private TableColumn<Book, String> authorColumn;
    @FXML
    private TableColumn<Book, String> isbnColumn;
    @FXML
    private TableColumn<Book, String> availabilityColumn;
    private Library library;

    @FXML
    private Button viewAllBookButton;

    @FXML
    private Button returnBookButton;

    @FXML
    private Button addBookButton;

    @FXML
    private Label usernameLabel; // For displaying the username

    @FXML
    private TextField bookTitle;
    @FXML
    private TextField Author;
    @FXML
    private TextField ISBN;
    @FXML
    private Button availability;

    @FXML
    private Label Booktitle;

    @FXML
    private Label author;

    @FXML
    private ComboBox categoryComboBox;

    @FXML
    private TextField searchField;


    @FXML
    private ObservableList<Book> borrowedBooks = FXCollections.observableArrayList();

    // This method will be called when the scene is initialized
    @FXML
    public void initialize() {
        bookTitle.setEditable(false);
        Author.setEditable(false);
        ISBN.setEditable(false);
        // Add items to the ComboBox
        categoryComboBox.getItems().addAll("All", "Book title", "Author", "ISBN");

        // Set default value
        categoryComboBox.setValue("All");

        library = new Library();
        library.readFile("src/main/java/com/example/demo/Library_Books.csv");
        handleViewAllBooks(); // Initial load of all books

        // Set up the event listener for row selection
        bookTableView.setOnMouseClicked(this::handleRowClick);
    }

    // Method to set the username dynamically from the login screen
    public void setUsername(String username) {
        this.username = username;
        usernameLabel.setText("Welcome, " + username + "!");

        ArrayList<Book> books = library.searchByBorrowerName(username);
        borrowedBooks.addAll(books);
    }

    // View all books button action
    @FXML
    private void handleViewAllBooks() {
        ArrayList<Book> books = library.books; // Get all books from the library

        if (books.isEmpty()) {
            displayMessage("View All Books", "No books found.");
        } else {
            ObservableList<Book> bookItems = FXCollections.observableArrayList();
            // Add each book object to the list
            bookItems.addAll(books);

            // Set custom cell value factories for each column
            bookTitleColumn.setCellValueFactory(cellData ->
                    new SimpleStringProperty(cellData.getValue().getTitle())
            );
            authorColumn.setCellValueFactory(cellData ->
                    new SimpleStringProperty(cellData.getValue().getAuthor())
            );
            isbnColumn.setCellValueFactory(cellData ->
                    new SimpleStringProperty(cellData.getValue().getISBN())
            );
            availabilityColumn.setCellValueFactory(cellData ->
                    new SimpleStringProperty(cellData.getValue().isAvailable() ? "Available" : "Not Available")
            );

            // Set the items for TableView
            bookTableView.setItems(bookItems);

            FilteredList<Book> filteredList = new FilteredList<>(bookItems, b -> true);

            searchField.textProperty().addListener((observable, oldValue, newValue) -> {
                filteredList.setPredicate(book -> {
                    // If no search value, display all books
                    if (newValue == null || newValue.isEmpty()) {
                        return true;
                    }

                    String searchKeyword = newValue.toLowerCase();

                    // Match the search with book title, author, or ISBN based on ComboBox
                    String category = categoryComboBox.getValue().toString();
                    switch (category) {
                        case "Book title":
                            return book.getTitle().toLowerCase().contains(searchKeyword);
                        case "Author":
                            return book.getAuthor().toLowerCase().contains(searchKeyword);
                        case "ISBN":
                            return book.getISBN().toLowerCase().contains(searchKeyword);
                        default:
                            // For "All", search across all fields
                            return book.getTitle().toLowerCase().contains(searchKeyword) ||
                                    book.getAuthor().toLowerCase().contains(searchKeyword) ||
                                    book.getISBN().toLowerCase().contains(searchKeyword);
                    }
                });
            });

            bookTableView.setItems(filteredList);
        }
    }


    @FXML
    private void handleAddBook() {
        // Create a dialog
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("Add New Book");

        // Create the input form using a GridPane
        GridPane gridPane = new GridPane();
        gridPane.setHgap(10);
        gridPane.setVgap(10);

        TextField titleField = new TextField();
        TextField authorField = new TextField();
        TextField isbnField = new TextField();

        gridPane.add(new Label("Book Title:"), 0, 0);
        gridPane.add(titleField, 1, 0);
        gridPane.add(new Label("Author:"), 0, 1);
        gridPane.add(authorField, 1, 1);
        gridPane.add(new Label("ISBN:"), 0, 2);
        gridPane.add(isbnField, 1, 2);

        dialog.getDialogPane().setContent(gridPane);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        // Show the dialog and wait for the user's response
        dialog.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                // Get user input and add the book
                String title = titleField.getText().trim();
                String author = authorField.getText().trim();
                String isbn = isbnField.getText().trim();

                if (!title.isEmpty() && !author.isEmpty() && !isbn.isEmpty()) {
                    Book newBook = new Book(title, author, isbn, true, "");
                    library.add(newBook, "src/main/java/com/example/demo/Library_Books.csv");
                    refreshTableView(); // Refresh TableView to include the new book
                    displayMessage("Add Book", "Book added successfully:\n" + newBook.toString());
                } else {
                    displayMessage("Add Book", "All fields are required to add a new book.");
                }
            }
        });
    }


    private void handleRowClick(MouseEvent event) {
        Book selectedBook = bookTableView.getSelectionModel().getSelectedItem();
        if (selectedBook != null) {
            updateBookDetails(selectedBook);
        }
    }

    private void updateBookDetails(Book book) {
        bookTitle.setText(book.getTitle());
        Author.setText(book.getAuthor());
        ISBN.setText(book.getISBN());
        Booktitle.setText(book.getTitle());
        author.setText(book.getAuthor());

        availability.setDisable(false); // Reset disable state

        if (borrowedBooks.contains(book)) {
            availability.setText("Return");
            availability.setStyle("-fx-background-color: red; -fx-text-fill: white;");
        } else if (book.isAvailable()) {
            availability.setText("Borrow");
            availability.setStyle("-fx-background-color: green; -fx-text-fill: white;");
        } else {
            availability.setText("Not Available");
            availability.setStyle("-fx-background-color: gray; -fx-text-fill: white;");
            availability.setDisable(true); // Disable for unavailable books
        }
    }

    private void saveBooksToFile() {
        File file = new File("src/main/java/com/example/demo/Library_Books.csv");
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            writer.write("Book Title,Author,ISBN,Availability,Borrower Name");
            writer.newLine();
            for (Book book : library.books) {
                writer.write(String.join(",", book.getTitle(), book.getAuthor(), book.getISBN(),
                        book.isAvailable() ? "True" : "False",
                        book.getBorrowerName() != null ? book.getBorrowerName() : ""));
                writer.newLine();
            }
        } catch (IOException e) {
            displayMessage("Error", "Failed to save books to file.");
            e.printStackTrace();
        }
    }

    // Event handler for Borrow button click
    @FXML
    private void handleBorrow(ActionEvent event) {
        Book selectedBook = bookTableView.getSelectionModel().getSelectedItem();
        if (selectedBook != null) {
            if (borrowedBooks.contains(selectedBook)) {
                // Returning the book
                selectedBook.setAvailability(true);
                selectedBook.setBorrowerName(""); // Clear borrower name when returning
                borrowedBooks.remove(selectedBook); // Remove from borrowed list
                updateBookDetails(selectedBook); // Update the UI based on changes
                saveBooksToFile(); // Save updated availability to the file
                displayMessage("Return Book", "The book \"" + selectedBook.getTitle() + "\" has been returned successfully.");
            } else if (selectedBook.isAvailable()) {
                // Borrowing the book
                selectedBook.setAvailability(false);
                selectedBook.setBorrowerName(username); // Ensure that the correct borrower name is set
                borrowedBooks.add(selectedBook); // Add to borrowed list
                updateBookDetails(selectedBook); // Update UI based on changes
                saveBooksToFile(); // Save updated availability to the file
                refreshTableView(); // Update the table view
                displayMessage("Borrow Book", "The book \"" + selectedBook.getTitle() + "\" has been borrowed successfully.");
            } else {
                displayMessage("Borrow Book", "This book is currently not available.");
            }
        } else {
            displayMessage("Borrow Book", "Please select a book to borrow or return.");
        }
    }

    @FXML
    private void handleViewBorrowedBooks(ActionEvent event) {
        if (bookTableView.getItems().equals(library.books)) {
            // Show borrowed books
            bookTableView.setItems(borrowedBooks);
            returnBookButton.setText("My book");
        } else {
            // Show all books
            ObservableList<Book> allBooks = FXCollections.observableArrayList(library.books);
            bookTableView.setItems(allBooks);
            returnBookButton.setText("My book");
        }
    }


    // Utility method to display messages in an alert box
    private void displayMessage(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

    private void refreshTableView() {
        ObservableList<Book> bookItems = FXCollections.observableArrayList(library.books);
        bookTableView.setItems(bookItems);
        bookTableView.refresh();
    }
}


package com.example.demo;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Library {

    // Create array list of Book objects
    ArrayList<Book> books = new ArrayList<Book>();

    // Method to add books
    public void add(Book book, String fileName) {
        books.add(book);
        // Call appendFile method to append the book into the file
        appendFile(fileName, book);
    }

    // Method to read file and load books into the ArrayList
    public void readFile(String fileName) {
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;

            //Skip the header
            reader.readLine();

            // Loop to read the file line by line
            while ((line = reader.readLine()) != null) {
                // split the comma to get the attribute
                String[] row = line.split(",");

                // Check if the row contains all necessary data
                String title = row[0];
                String author = row[1];
                String ISBN = row[2];
                String borrowerName = "";
                boolean available = Boolean.parseBoolean(row[3]); //To convert the String into boolean
                if (row.length == 5) {
                    borrowerName = row[4];
                }
                // Create a book object and add it to the ArrayList
                Book book = new Book(title, author, ISBN, available, borrowerName);
                books.add(book);
            }
        } catch (FileNotFoundException e) { //Exception if the file doesn't exist
            System.out.println("File not found");
        } catch (IOException e) { //Exception if cannot read from file
            System.out.println("Error reading from file");
        }
    }

    // Method to append a new book to the file
    public void appendFile(String fileName, Book book) {
        try (FileWriter writer = new FileWriter(fileName, true)) {  // write into the file
            // Append the book details as a string
            writer.append(book.toString()).append("\n");
            System.out.println("The book has been successfully added to the file");
        } catch (IOException e) { //Exception if cannot write into file
            System.out.println("Cannot write into file");
        }
    }

    // Method to search book by title
    public ArrayList<Book> searchByTitle(String title) {
        ArrayList<Book> result = new ArrayList<>();
        for (int i = 0; i < books.size(); i++) {
            Book book = books.get(i);
            // Use IgnoreCase to ignore case sensitive issues
            if (book.getTitle().equalsIgnoreCase(title)) {
                result.add(book);
            }
        }
        return result;
    }

    // Method to search book by Author
    public ArrayList<Book> searchByAuthor(String author) {
        ArrayList<Book> result = new ArrayList<>();
        for (int i = 0; i < books.size(); i++) {
            Book book = books.get(i);
            if (book.getAuthor().equalsIgnoreCase(author)) {
                result.add(book);
            }
        }
        return result;
    }

    // Method to search book by ISBN
    public ArrayList<Book> searchByISBN(String ISBN) {
        ArrayList<Book> result = new ArrayList<>();
        for (int i = 0; i < books.size(); i++) {
            Book book = books.get(i);
            if (book.getISBN().equalsIgnoreCase(ISBN)) {
                result.add(book);
            }
        }
        return result;
    }

    // Method to search the borrowerName
    public ArrayList<Book> searchByBorrowerName(String borrowerName) {
        ArrayList<Book> result = new ArrayList<>();
        for (int i = 0; i < books.size(); i++) {
            Book book = books.get(i);
            if (book.getBorrowerName().equalsIgnoreCase(borrowerName)) {
                result.add(book);

            }
        }
        return result;
    }
}
